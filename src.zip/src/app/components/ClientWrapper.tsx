"use client"

import { SessionProvider } from "next-auth/react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import type React from "react" // Added import for React

export function ClientWrapper({ children }: { children: React.ReactNode }) {
    return (
        <SessionProvider>
            <nav className="bg-gray-800 text-white p-4">
                <div className="container mx-auto flex justify-between items-center">
                    <Link href="/" className="text-xl font-bold">
                        Marketing Mastermind
                    </Link>
                    <div className="space-x-4">
                        <Link href="/play">
                            <Button variant="ghost">Play Now</Button>
                        </Link>
                        <Link href="/auth/signin">
                            <Button variant="ghost">Sign In</Button>
                        </Link>
                        <Link href="/auth/register">
                            <Button variant="ghost">Register</Button>
                        </Link>
                    </div>
                </div>
            </nav>
            {children}
        </SessionProvider>
    )
}

